const score = {
            wins:0,
            losses:0, 
             ties:0
            
        };
   updatescoreElement ();
         console.log(localStorage.getItem('score'));
        
       function playGame (playerMove) {
  const computerMove = pickcomputerMove ();
     let results ='';
  if (playerMove === 'scissors') { 
  
     if (computerMove === 'scissors') {results = 'Tie.';}
     else if (computerMove === 'paper') {results = ' you lose.';}
     else if (computerMove === 'Rock') {results = ' you win.';}
     
     
     }
     else if (playerMove === 'paper') {
             if (computerMove === 'paper')  {results = 'Tie.';}
             
     else if (computerMove === 'Rock') {results = ' you lose.';}
     else if (computerMove === 'scissors') {results = ' you win.';}
     }
     
     
     else if (playerMove === 'Rock') {
             if (computerMove === 'Rock')  {results = 'Tie.';}
             
     else if (computerMove === 'paper') {results = ' you win.';}
     else if (computerMove === 'scissors') {results = ' you lose.';}
     
     }
     if (results === ' you win.') {
         score.wins =  score.wins + 1;
   }
     else if (results === ' you lose.') {
         score.losses = score.losses + 1;
     }
     else if (results === 'Tie.') {
         score.ties = score.ties + 1;
     }
     
     
localStorage.setItem('score', JSON.stringify(score));

     updatescoreElement ();
     
document.querySelector('.js-results')
.innerHTML = results;


document.querySelector('.js-moves').innerHTML
 = `you <img src="${playerMove}.jpg">
  <img src="${computerMove}.jpg">computer`;
        }
        let computerMove = '';
        
   function updatescoreElement ()    {
       
              document.querySelector('.js-score').innerHTML = `wins: ${score.wins}, losses: ${score.losses}, ties: ${score.ties}`;
   }
       
        function pickcomputerMove ()
        
        {
        const randomNumber = Math.random();
            if (randomNumber >= 0 && randomNumber < 1/3) {computerMove = 'rock' ;}
     else if (randomNumber >= 1/3 && randomNumber < 2/3) {computerMove = 'paper' ;}
     else if (randomNumber >= 2/3 && randomNumber < 1) {computerMove = 'scissors';}
     console.log(computerMove);
     
     return computerMove;
        }
        
     
     